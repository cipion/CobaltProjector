(function () {
    'use strict';

    angular
        .module('app')
        .controller('HomeController', HomeController);

    HomeController.$inject = [ '$location', '$cookies',  '$scope', 'MaisonService'];
    function HomeController( $location, $cookies,  $scope, MaisonService) {
        var vm = this;
		var data = {};
		
				
            		
	

}) ();



